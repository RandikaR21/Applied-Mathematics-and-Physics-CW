﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task03_Complete : MonoBehaviour
{
    public GameObject allWalls;  // Get the gameobject of all walls.
    Task03_Walls wallsComponents; //Get the components attach to each wall.

    public Vector2 velocity = new Vector2(); //Get the 2D vector input.
    public Vector3 v = new Vector3(); //3D vector of velocity used for the calculation.
    Vector3 position = new Vector3(); //#D vector to represent the position of the ball.
    
    
    
    float[,] boudlines; //A 2D array which holds the gradient and the y-intercept of the non-axis aligned lines



    Vector3 friction = new Vector3(); //3D vector to store the friction.
    Vector3 reversV = new Vector3(); //3D vector to represent the reverse velocity due to friction.
    public float f;  //User input of the friction in the plane.



    // Start is called before the first frame update
    void Start()
    {
        wallsComponents = allWalls.GetComponent("Task03_Walls") as Task03_Walls; //Get the components attach to each wall.

        
        v.x = velocity.x;
        v.z = velocity.y;
        position = transform.position;
        position.y = 0.5f;
        boudlines = new float[4, 3] { { 1, 14, -14 / 1 }, { 1, -14, 14 / 1 }, { -1, 14, -14 / -1 }, { -1, -14, 14 / -1 } };
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        friction = VectorMaths.scalarMultiply(VectorMaths.normaliseVector(v), (f * 9.81f)); //Calculate the frictional force 
        reversV = VectorMaths.scalarMultiply(friction, Time.fixedDeltaTime); //Caluate reverse velocity.
        bool foundFlag = false;
        

        if ((int)VectorMaths.vectorMagnitude(v) > 0)
        {

            v -= reversV; //Reduce the velocity gradually.
            position = VectorMaths.addVectors(position, VectorMaths.scalarMultiply(v, Time.fixedDeltaTime));

            //Check whether the ball is inside the boundaries.
            if (((wallsComponents.verticalLeft.transform.position.x) + (wallsComponents.transform.localScale.x + transform.localScale.x)) < position.x && position.x < ((wallsComponents.verticalRight.transform.position.x) - (wallsComponents.transform.localScale.x + transform.localScale.x))
                && 
                (((wallsComponents.verticalLeft.transform.position.x) + (wallsComponents.transform.localScale.x + transform.localScale.x)) < position.z && position.z < ((wallsComponents.verticalRight.transform.position.x) - (wallsComponents.transform.localScale.x + transform.localScale.x))))
            {
                
                for (int i = 0; i < boudlines.GetLength(0); i++) //Iterate through the list of equations to find whether the ball collided with the non- axis aligned walls.
                {
                    Vector2 b1 = new Vector2(0, boudlines[i, 1]);
                    Vector2 b2 = new Vector2(boudlines[i, 2], 0);
                    
                    if (VectorMaths.onBoundline(new Vector2(position.x, position.z), boudlines[i, 0], boudlines[i, 1], 2)) //Call the onBoundLine method from the VectorMaths Class.
                    {

                        Vector2 vecT = VectorMaths.vectorReflecion_AxisNotAlign(new Vector2(v.x, v.z), b1, b2); //Call the method from VectorMaths class for Vector reflection  axis non aligned.
                        v.x = vecT.x; //Update the velocity vector.
                        v.z = vecT.y;
                        foundFlag = true; //Flag to represent that the ball collided with a non-axis aligned wall.
                        break;
                        




                    }
                }
                if (!foundFlag)
                {
                    transform.position = position;
                }
            }
            else
            {

                if (position.x > ((wallsComponents.verticalRight.transform.position.x) - (wallsComponents.transform.localScale.x + transform.localScale.x)) || position.x < ((wallsComponents.verticalLeft.transform.position.x) + (wallsComponents.transform.localScale.x + transform.localScale.x)))
                {
                    Vector2 reflectedVec = VectorMaths.vectorReflecion_AxisAlign(new Vector2(v.x, v.z),"v"); //Call the method from VectorMaths class for Vector reflection , axis aligned vertically.

                    v.x = reflectedVec.x; //Update the velocity vector.
                    v.z = reflectedVec.y;
                    transform.position = position; //Update the position vector.

                }
                else
                {
                    Vector2 reflectedVec = VectorMaths.vectorReflecion_AxisAlign(new Vector2(v.x, v.z),"h"); //Call the method from VectorMaths class for Vector reflection , axis aligned horizontally.
                    v.x = reflectedVec.x;
                    v.z = reflectedVec.y;
                    transform.position = position;

                }

            }
        }
    }
}
