﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task02_Projectile : MonoBehaviour
{
    public Vector3 u = new Vector3(); //User input of the objects velocity in 3D.
    public float e; //User input of coefficient of restitution.

    Vector3 v; //3D vector representing the current velocity.
    Vector3 current_position; //3D vector representing the current position.
    Vector3 gravity; //3D vector representing the gravity.
    float dt; //Time step.
    bool stopProjectile;




    // Start is called before the first frame update
    void Start()
    {
        dt = 0.1F; // Delta Time (Change of time).
        Time.fixedDeltaTime = dt; //Set the timestep to 0.1 seconds.
        gravity = new Vector3(0F, -9.81F, 0F); //Initialise the gravity vector.
        current_position = transform.position; //Initialise the current position vector with the objects current position.
        v = u ; //At first the starting velocity = current velocity.
        stopProjectile = false;

    }

    // Update is called once per frame
    void FixedUpdate()
    {
       

        if (stopProjectile == false) //Check whether the ball velocity is 0.
        {
            v += gravity * dt; //Calculate the new Velocity.
            current_position += v * dt; //Calculate new position.
            /**
             * If the y component of object is below zero it means the collision has occured. 
             * So inorder to bounce the ball we should prevent the balls positions y component reach below 0.
             */
            if (current_position.y <= 0) 
            {
                current_position.y = 0F;
                transform.position = current_position;
                u = VectorMaths.scalarMultiply(u, e); //Multiply the velocity with the coefficient of restitution in order to find new velocity.
                if (u.y > 1) //Check whether the velocity of the ball is enough to cause a projectile.
                {
                    v = u;
                }
                else
                {
                    stopProjectile = true;

                }

            }
            else
            {
                transform.position = current_position; //Update the ball's postion.

            }
        }

    }
}
