﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task03_Extension : MonoBehaviour
{
    /**
     * This class is used to detect the collisions of the balls. 
     */
    public GameObject sphere01;
    public GameObject sphere02;

    Vector3 finalVelocitySphere01 = new Vector3(); //Final velocity of the ball.
    Vector3 finalVelocitySphere02 = new Vector3(); //Final velocity of the ball.

    Task03_Complete s1;
    Task03_Complete s2;
    // Start is called before the first frame update
    void Start()
    {
        s1 =sphere01.GetComponent("Task03_Complete") as Task03_Complete; //Get the components of sphere 01.
        s2 = sphere02.GetComponent("Task03_Complete") as Task03_Complete; //Get the components of sphere 02.
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (VectorMaths.vectorsCloseBy(sphere01.transform.position , sphere02.transform.position , sphere01.transform.localScale.x + sphere02.transform.localScale.x)) //Check whether the balls collided using the method from task 01.
        {
         
            //Calculate the velocities of the balls after colision.
            finalVelocitySphere01 = s1.v - VectorMaths.dotProduct(VectorMaths.subVectors(s1.v, s2.v), VectorMaths.subVectors(sphere01.transform.position, sphere02.transform.position)) * 1/ VectorMaths.vectorMagnitude(VectorMaths.subVectors(sphere01.transform.position, sphere02.transform.position)) * VectorMaths.subVectors(sphere01.transform.position, sphere02.transform.position);
            finalVelocitySphere02 = s2.v - VectorMaths.dotProduct(VectorMaths.subVectors(s2.v, s1.v), VectorMaths.subVectors(sphere02.transform.position, sphere01.transform.position)) * 1 / VectorMaths.vectorMagnitude(VectorMaths.subVectors(sphere02.transform.position, sphere01.transform.position)) * VectorMaths.subVectors(sphere02.transform.position, sphere01.transform.position);
            
            //Update the velocity of the balls.
            s1.v = finalVelocitySphere01;
            s2.v = finalVelocitySphere02;
        }
       

    }
}
