﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VectorMaths
{
    /*
     * Method to add two vectors.
     */
    public static Vector3 addVectors(Vector3 vecA, Vector3 vecB) {
        float resultX = vecA.x + vecB.x; // Extract x coordinates of the two vectors and add each other.
        float resultY = vecA.y + vecB.y; // Extract y coordinates of the two vectors and add each other.
        float resultZ = vecA.z + vecB.z; // Extract z coordinates of the two vectors and add each other.

        return new Vector3(resultX, resultY, resultZ); // Return a new vector containing the resultant coordinates.

    } // For 3D vector.

    public static Vector2 addVectors(Vector2 vecA, Vector2 vecB) {
        float resultX = vecA.x + vecB.x; // Extract x coordinates of the two vectors and add each other.
        float resultY = vecA.y + vecB.y; // Extract y coordinates of the two vectors and add each other.
        
        return new Vector2(resultX, resultY); // Return a new vector containing the resultant coordinates.
    } // For 2D vector.

//=============================================================================================================================================================================
    /*
     * Method to substract two vectors.
     */
    public static Vector3 subVectors(Vector3 vecA, Vector3 vecB) {
        float resultX = vecA.x - vecB.x; // Extract x coordinates of the two vectors and substract each other.
        float resultY = vecA.y - vecB.y; // Extract y coordinates of the two vectors and substract each other.
        float resultZ = vecA.z - vecB.z; // Extract z coordinates of the two vectors and substract each other.

        return new Vector3(resultX, resultY, resultZ); // Return a new vector containing the resultant coordinates.
    } // For 3D vector.

    public static Vector2 subVectors(Vector2 vecA, Vector2 vecB) {
        float resultX = vecA.x - vecB.x; // Extract x coordinates of the two vectors and substract each other.
        float resultY = vecA.y - vecB.y; // Extract y coordinates of the two vectors and substract each other.
        

        return new Vector3(resultX, resultY); // Return a new vector containing the resultant coordinates.
    } // For 2D vector.

//=============================================================================================================================================================================

    /*
     * Method to multiply a vector by a scalar.
     */
    public static Vector3 scalarMultiply(Vector3 vec , float multiple) {
        float resultX = vec.x * multiple; // Extract x coordinates of  vectors and multiply by the scalar multiple.
        float resultY = vec.y * multiple; // Extract y coordinates of  vectors and multiply by the scalar multiple.
        float resultZ = vec.z * multiple; // Extract z coordinates of  vectors and multiply by the scalar multiple.

        return new Vector3(resultX, resultY, resultZ);
    } // For 3D vector.

    public static Vector2 scalarMultiply(Vector2 vec , float multiple) {
        float resultX = vec.x * multiple; // Extract x coordinates of  vectors and multiply by the scalar multiple.
        float resultY = vec.y * multiple; // Extract y coordinates of  vectors and multiply by the scalar multiple.
        
        return new Vector2(resultX, resultY);
    } // For 2D vector.

//=============================================================================================================================================================================

    /*
     * Method to find the unit vector of an vector.
     */
    public static Vector3 normaliseVector(Vector3 vec) {
        float resultX = (vec.x / vectorMagnitude(vec)); // Extract x coordinates of the  vectors divide by the magnitude of the vector.
        float resultY = (vec.y / vectorMagnitude(vec)); // Extract y coordinates of the  vectors divide by the magnitude of the vector.
        float resultZ = (vec.z / vectorMagnitude(vec)); // Extract z coordinates of the  vectors divide by the magnitude of the vector.

        return new Vector3(resultX, resultY, resultZ); // Return a new vector containing the resultant coordinates.
    } // For 3D vector.

    public static Vector2 normaliseVector(Vector2 vec) {
        float resultX = (vec.x / vectorMagnitude(vec)); // Extract x coordinates of the  vectors divide by the magnitude of the vector.
        float resultY = (vec.y / vectorMagnitude(vec)); // Extract y coordinates of the  vectors divide by the magnitude of the vector.

        return new Vector2(resultX, resultY); // Return a new vector containing the resultant coordinates.
    } // For 2D vector. 

//=============================================================================================================================================================================
    /*
     * Method to find the unit v=direction vector 
     * between two position vectors.
     */
    public static Vector3 unitDirectionVector(Vector3 vec1, Vector3 vec2) {
        return normaliseVector(subVectors(vec2, vec1));
    } // For 3D vector.

    public static Vector2 unitDirectionVector(Vector2 vec1, Vector2 vec2) {
        return normaliseVector(subVectors(vec2, vec1));
    } // For 2D vector.

//=============================================================================================================================================================================
    /*
     * Method to reflecct a angle on colission to an axis alligned surface.
     */
    public static Vector3 vectorReflecion_AxisAlign(Vector3 vec , string axis) {
        if (axis.Equals("h"))
        {
            return new Vector3(vec.x, -vec.y, vec.z); //If the reflection is horizontal the y component of velocity inverts.
        }
        else
        {
            return new Vector3(-vec.x, vec.y, vec.z); //If the reflection is vertical the x component of velocity inverts.
        }
    } // For 3D vector.

    public static Vector2 vectorReflecion_AxisAlign(Vector2 vec , string axis) {
        if (axis.Equals("h"))
        {
            
            return new Vector2(vec.x, -vec.y);
        }
        else
        {
            return new Vector3(-vec.x, vec.y);
        }
    } // For 2D vector.

//=============================================================================================================================================================================
    /*
     *  Method to reflecct a angle on colission to an axis non-alligned surface.
     */
    public static Vector3 vectorReflecion_AxisNotAlign(Vector3 vec, Vector3 b1, Vector3 b2) {
        Vector3 n = crossProduct(b1, b2);
        Debug.Log(n);
        Vector3 normalisedN = normaliseVector(n);
        Debug.Log(normalisedN);
        Vector3 reverseVec = scalarMultiply(vec, -1);
        Vector3 p = scalarMultiply(normalisedN, dotProduct(reverseVec, normalisedN));
        return addVectors(scalarMultiply(p, 2), vec);
    } // For 3D vector.

    public static Vector2 vectorReflecion_AxisNotAlign(Vector2 vec, Vector2 b1, Vector2 b2) {
        Vector2 slope = subVectors(b1, b2);

        Vector2 n = new Vector2(slope.y, 0 - slope.x);
        Vector2 normalisedN = normaliseVector(n);
        Vector2 reverseVec = scalarMultiply(vec, -1);
        Vector2 p = scalarMultiply(normalisedN, dotProduct(reverseVec, normalisedN));
        return addVectors(scalarMultiply(p, 2), vec);

    } // For 2D vector.
//=============================================================================================================================================================================
    /*
     * Method to find the magnitude of the vector.
     */
    public static float vectorMagnitude(Vector3 vec ) {
        return (float)(Math.Sqrt(Math.Pow(vec.x, 2) + Math.Pow(vec.y, 2) + Math.Pow(vec.z, 2))); //Pythagorus theorem
    } // For 3D vector.
    public static float vectorMagnitude(Vector2 vec) {
        return (float)(Math.Sqrt(Math.Pow(vec.x, 2) + Math.Pow(vec.y, 2))); //Pythagorus theorem
    } // For 2D vector.
    
//=============================================================================================================================================================================
    /*
     * Method to calculate the dot product of two vectors.
     */
    public static float dotProduct(Vector3 vecA, Vector3 vecB) {
        float resultX = vecA.x * vecB.x; // Extract x coordinates of the two vectors and multiply each other.
        float resultY = vecA.y * vecB.y; // Extract y coordinates of the two vectors and multiply each other.
        float resultZ = vecA.z * vecB.z; // Extract z coordinates of the two vectors and multiply each other.

        return (resultX + resultY + resultZ); // Return the sum of the resultant coordinates.
    } // For 3D vector.
    public static float dotProduct(Vector2 vecA, Vector2 vecB) {
        float resultX = vecA.x * vecB.x; // Extract x coordinates of the two vectors and multiply each other.
        float resultY = vecA.y * vecB.y; // Extract y coordinates of the two vectors and multiply each other.

        return (resultX + resultY); // Return the sum of the resultant coordinates.
    } // For 2D vector.

//=============================================================================================================================================================================

    /*
     * Method to find whether 2 objects are close by (Collision Detection).
     */
    public static bool vectorsCloseBy(Vector3 vecA, Vector3 vecB, float tolerance) { // Tolerance is the distance between the 2 centers of the objects.
        if (vectorMagnitude(subVectors(vecB, vecA)) < tolerance) // The magnitude of substraction of Vector B by A will give the distance between the to objects.
        {
            return true;
        }
        else
        {
            return false;
        }
    } // For 3D vector.

    public static bool vectorsCloseBy(Vector2 vecA, Vector2 vecB, float tolerance) {
        if (vectorMagnitude(subVectors(vecB, vecA)) < tolerance)
        {
            return true;
        }
        else
        {
            return false;
        }
    } // For 2D vector.

//=============================================================================================================================================================================
    /*
     * Method to find whether acpoint is on a line.
     */
    public static bool onBoundline(Vector3 vec, float m, float c , float tolerance) { 
        float y;
        
        y = m * vec.x + c; //Using the line equation,the x coordinate of the vector is subtituted and the y value is calculated.
        if (y-tolerance < vec.y && vec.y < y+tolerance) //Check whether the vector's y coordinate is in the range of the calculated y. 
        {
            return true;
        }
        else
        {
            return false;
        }
    } // For 3D vector.
    public static bool onBoundline(Vector2 vec, float m, float c, float tolerance)
    {
        float y;
        
        y = m * vec.x + c;
        if (y - tolerance < vec.y && vec.y < y + tolerance)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
//=============================================================================================================================================================================

    /*
     *  Method to calculate the cross product between two vectors.
     */

    public static Vector3 crossProduct(Vector3 vecA, Vector3 vecB) 
    {
        Vector3 resultVector = new Vector3();
        resultVector.x = (vecA.y * vecB.z) - (vecA.z * vecB.y);
        resultVector.y = (vecA.z * vecB.x) - (vecA.x * vecB.z);
        resultVector.z = (vecA.x * vecB.y) - (vecA.y * vecB.x);

        return resultVector;
    }

    /**
     * Method to return a zero vector
     */
    public static Vector3 zeroVector()
    {
        return new Vector3(0f, 0f, 0f);
    }




}
