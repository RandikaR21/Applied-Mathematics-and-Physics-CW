﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task03_Walls : MonoBehaviour
{
    /**
     * This script is used to get all the walls objects into a single component.
     */
    public GameObject horizontalUp;
    public GameObject horizontalDown;
    public GameObject verticalLeft;
    public GameObject verticalRight;
    public GameObject topRight;
    public GameObject topLeft;
    public GameObject bottomRight;
    public GameObject bottomLeft;

   
    // Start is called before the first frame update
    void Start()
    {
        

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
