﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task01_Test : MonoBehaviour
{
    Vector3 resultVector = new Vector3(); //3D vector to represent the result of my methods from the vector maths class.
    Vector3 expectedVector = new Vector3(); //3D vector to represent the actual expected results generated from the unity engine.
    bool resultBoolean; //Boolean to epresent the result of my methods from the vector maths class
    bool expectedBoolean;//Boolean to represent the actual expected results generated from the unity engine
    float resultFloat;//float to epresent the result of my methods from the vector maths class
    float expectedFloat;//float to represent the actual expected results generated from the unity engine
    bool passed; //Boolean to represent whether the test is passed or not.
    public Vector3 vectA = new Vector3();
    public Vector3 vectB = new Vector3();

    // Start is called before the first frame update
    void Start()
    {
        vectA = new Vector3(1f,2f,3f);
        vectB = new Vector3(-5f,4f,3f);

        //Test Addition method.
        resultVector = VectorMaths.addVectors(vectA,vectB);
        expectedVector = (vectA + vectB);
        if (resultVector == expectedVector)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Addition Method of " + vectA + " and " + vectB + " ; " + " Expected : " + expectedVector + " Result : " + resultVector + " Test passed : " + passed);

        //Test substraction method.
        resultVector = VectorMaths.subVectors(vectA, vectB);
        expectedVector = (vectA - vectB);
        if (resultVector == expectedVector)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Substraction Method of " + vectA + " and " + vectB + " ; " + " Expected : " + expectedVector + " Result : " + resultVector + " Test passed : " + passed);

        // Test scalar multiplication.
        resultVector = VectorMaths.scalarMultiply(vectB , 5);
        expectedVector = vectB * 5;
        if (resultVector == expectedVector)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Scalar Multiplication Method of " + vectB + " by " + 5 + " ; " + " Expected : " + expectedVector + " Result : " + resultVector + " Test passed : " + passed);

        // Test normalisation method.
        resultVector = VectorMaths.normaliseVector(vectA);
        expectedVector = vectA.normalized;
        if (resultVector == expectedVector)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Normalising method of "+vectA+" ; " + " Expected : " + expectedVector + " Result : " + resultVector + " Test passed : " + passed);

        // Test the unit direction vector between the 2 vectors.
        resultVector = VectorMaths.unitDirectionVector(vectA, vectB);
        expectedVector = (vectB - vectA).normalized;
        if (resultVector == expectedVector)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Finding the unit direction vector method between  " + vectA + " and " + vectB + " ; " + " Expected : " + expectedVector + " Result : " + resultVector + " Test passed : " + passed);

        //Test vector reflection horizontally.
        resultVector = VectorMaths.vectorReflecion_AxisAlign(vectA,"h");
        expectedVector = Vector3.Reflect(vectA, new Vector3(0f,1f,0f));
        if (resultVector == expectedVector)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Relecting  " + vectA + " horizontally ; " + " Expected : " + expectedVector + " Result : " + resultVector + " Test passed : " + passed);

        //Test vector reflection vertically.
        resultVector = VectorMaths.vectorReflecion_AxisAlign(vectA, "v");
        expectedVector = Vector3.Reflect(vectA, new Vector3(1f, 0f, 0f));
        if (resultVector == expectedVector)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Relecting  " + vectA + " vertically ; " + " Expected : " + expectedVector + " Result : " + resultVector + " Test passed : " + passed);

        //Test for the reflection of vector non axis aligned.
        resultVector = VectorMaths.vectorReflecion_AxisNotAlign(new Vector2(3f, 4f), new Vector2(0f, 0f), new Vector2(4f, 4f));

        expectedVector = new Vector2(4f, 3f);
        if (resultVector == expectedVector)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Relecting  " + new Vector2(3f, 4f) + " on line y=x ; " + " Expected : " + expectedVector + " Result : " + resultVector + " Test passed : " + passed);


        // Test the calculation of the magnitude of the vector.
        resultFloat = VectorMaths.vectorMagnitude(vectA);
        expectedFloat = vectA.magnitude;
        if (resultFloat == expectedFloat)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Magnitude of " + vectA +  " ; " + " Expected : " + expectedFloat + " Result : " + resultFloat + " Test passed : " + passed);


        //Test the dot product of the 2 vectors.
        resultFloat = VectorMaths.dotProduct(vectA, vectB);
        expectedFloat = Vector3.Dot(vectA, vectB);
        if (resultFloat == expectedFloat)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Dot product of " + vectA + " and " + vectB + " ; " + " Expected : " + expectedFloat + " Result : " + resultFloat + " Test passed : " + passed);


        //Test for the collision detection method.
        resultBoolean = VectorMaths.vectorsCloseBy(vectA, vectB,2);
        expectedBoolean = false;
        expectedBoolean = false;
        if (resultBoolean == expectedBoolean)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Method to check whether vectors  " + vectA + " and " + vectB + " nearly equal to radius ; " + expectedBoolean + " Result : " + resultBoolean + " Test passed : " + passed);



        //Test for on the boundline method.
        resultBoolean = VectorMaths.onBoundline(vectA,1f,0f,0.5f);
        expectedBoolean = false;
        if (resultBoolean == expectedBoolean)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Method to check whether vector " + vectA + " is on line y=x  ; " + " Expected : " + expectedBoolean + " Result : " + resultBoolean + " Test passed : " + passed);



        //Test the cross product function.
        resultVector = VectorMaths.crossProduct(vectA, vectB);
        expectedVector = Vector3.Cross(vectA, vectB);
        if (resultVector == expectedVector)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Cross product of " + vectA + " and " + vectB + " ; " + " Expected : " + expectedVector + " Result : " + resultVector + " Test passed : " + passed);

        //Test to check for the zero vector method.
        resultVector = VectorMaths.zeroVector();
        expectedVector = new Vector3(0f, 0f, 0f);
        if (resultVector == expectedVector)
        {
            passed = true;
        }
        else
        {
            passed = false;
        }
        Debug.Log("Method to return a zero vector  ; " + " Expected : " + expectedVector + " Result : " + resultVector + " Test passed : " + passed);


    }
}
