﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task03_OnlyAxisAligned : MonoBehaviour
{
    public Vector2 velocity = new Vector2(); //Get the 2D vector input.
    Vector3 v = new Vector3(); //3D vector of velocity used for the calculation.
    Vector3 position = new Vector3(); //#D vector to represent the position of the ball.
    

    Vector3 friction = new Vector3(); //3D vector to store the friction.
    Vector3 reversV = new Vector3(); //3D vector to represent the reverse velocity due to friction.
   
    public float f; //User input of the friction in the plane.

    public GameObject allWalls;  // Get the gameobject of all walls.
    Task03_Walls wallsComponents; //Get the components attach to each wall.



    // Start is called before the first frame update
    void Start()
    {
        
        
        v.x = velocity.x; //Convert the 2D input to 3D.
        v.z = velocity.y; //Convert the 2D input to 3D.
        position = transform.position;
        wallsComponents = allWalls.GetComponent("Task03_Walls") as Task03_Walls; //Get the components attach to each wall.

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        friction = VectorMaths.scalarMultiply(VectorMaths.normaliseVector(v) , (f * 9.81f)); //Calculate the frictional force 
        reversV = VectorMaths.scalarMultiply( friction , Time.fixedDeltaTime); //Caluate reverse velocity.
        
        if ((int)VectorMaths.vectorMagnitude(v) > 0 )
        {
            v -= reversV;
            position = VectorMaths.addVectors( position , VectorMaths.scalarMultiply(v, Time.fixedDeltaTime));
           
            if (position.x > ((wallsComponents.verticalRight.transform.position.x ) - (wallsComponents.transform.localScale.x + transform.localScale.x) ) || position.x < ((wallsComponents.verticalLeft.transform.position.x) + (wallsComponents.transform.localScale.x + transform.localScale.x))) //Check whether the ball exceeds the vertical boundaries.
            {
                Vector2 reflectedVec = VectorMaths.vectorReflecion_AxisAlign(new Vector2(v.x, v.z), "v"); //Call the method from VectorMaths class for Vector reflection , axis aligned.
                v.x = reflectedVec.x; //Update the velocity vector.
                v.z = reflectedVec.y;
                transform.position = position; //Update the position.
            }
            else if (position.z > ((wallsComponents.horizontalUp.transform.position.z) - (wallsComponents.transform.localScale.z + transform.localScale.z)) || position.z < ((wallsComponents.horizontalDown.transform.position.z) + (wallsComponents.transform.localScale.z + transform.localScale.z))) //Check whether the ball exceeds the Horizontal boundaries.
            {
                Vector2 reflectedVec = VectorMaths.vectorReflecion_AxisAlign(new Vector2(v.x, v.z), "h"); //Call the method from VectorMaths class for Vector reflection , axis aligned.
                v.x = reflectedVec.x;
                v.z = reflectedVec.y;
                transform.position = position;
            }
            else
            {

                transform.position = position; //Update the position of the ball.
            }




        }
        
    }
}
